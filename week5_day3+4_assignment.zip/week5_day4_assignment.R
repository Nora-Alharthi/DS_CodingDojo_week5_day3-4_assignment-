library("nycflights13")

install.packages("fueleconomy")
install.packages("nasaweather")
install.packages("babynames")
install.packages("Lahman")
install.packages("maps")

library("fueleconomy")
library("nasaweather")
library("babynames")
library("Lahman")
library("ggplot2")
library("maps")

View(airlines)
View(airports)
View(planes)
View(weather)
View(flights)



################### Exercise 13.2.1 ###################
#Imagine you wanted to draw (approximately) the route each plane flies from its 
#origin to its destination. What variables would you need? What tables would you 
#need to combine?

# >> To draw the route each plane flies from its origin to its destination I need
# >> the flights and airports tables. The origin "origin" and destination "dest" 
# >> from flights table. The longitude "lon" and latitude "lat" from airport table. 
# >> This requires join flights to airports.

flights_join <- flights %>%
  left_join(select(airports, origin = faa, origin_lat = lat, origin_lon = lon),
             by = "origin"
  ) %>%
  left_join(select(airports, dest = faa, dest_lat = lat, dest_lon = lon),
             by = "dest"
  )
flights_join


################### Exercise 13.2.2 ###################
#I forgot to draw the relationship between weather and airports. 
#What is the relationship and how should it appear in the diagram?

# >> The column "faa" in airports table is a foreign key in weather table at 
# >> "origin" column


################### Exercise 13.2.3 ###################
#Weather only contains information for the origin (NYC) airports. 
#If it contained weather records for all airports in the USA, what additional 
#relation would it define with flights?

# >> If the weather table contained weather records for all airports in the USA,
# >> then it would provide the weather for the destination of each flight


################### Exercise 13.2.4 ###################
#We know that some days of the year are “special”, and fewer people than usual 
#fly on them. How might you represent that data as a data frame? What would be 
#the primary keys of that table? How would it connect to the existing tables?

# >> I would create a new table "special" containing the information of the 
# >> special days. it would connect to the existing tables through keys
# >> "year, month, and day" >> the primary keys

################### Exercise 13.3.1 ###################
#Add a surrogate key to flights.

flights %>%
  mutate(id = row_number()) %>%
  select(id, everything())

View(flights)


################### Exercise 13.3.2 ###################
#Identify the keys in the following datasets:
#The primary keys for Lahman::Batting are playerID, yearID, stint, teamID, and lgID

View(Batting)     # >> playerID, yearID, stint
View(babynames)   # >> year, sex, name
View(atmos)       # >> lat, long, year, month
View(vehicles)    # >> id
View(diamonds)    # >> No primary key here


################### Exercise 13.3.3 ###################
#Draw a diagram illustrating the connections between the Batting, Master, 
#and Salaries tables in the Lahman package. Draw another diagram that shows the 
#relationship between Master, Managers, AwardsManagers.
#How would you characterize the relationship between the Batting, Pitching, 
#and Fielding tables?

View(Master)
View(Salaries)
View(Batting) 
View(Managers)
View(AwardsManagers)
View(Fielding)

# >> For the Batting, Master, and Salaries tables:
# >> Master:Primary key: playerID
# >> Batting:Primary key: playerID, yearID, stint, Foreign keys:playerID = Master$playerID 
# >> Salaries:Primary key: yearID, teamID, playerID,Foreign keys:playerID = Master$playerID


# >> For the Master, Manager, and AwardsManagers tables:
# >> Master:Primary key: playerID
# >> Managers:Primary key: yearID, teamID, inseason,Foreign keys:playerID references Master$playerID
# >> AwardsManagers:Primary key: playerID, awardID, yearID,Foreign keys:playerID references Master$playerID 


# >> The primary keys of Batting and Fielding are the following:
# >> Batting: (playerID, yearID, stint)
# >> Fielding: (playerID, yearID, stint)


################### Exercise 13.4.1 ###################
#Compute the average delay by destination, then join on the airports data frame 
#so you can show the spatial distribution of delays. Here’s an easy way to draw 
#a map of the United States

airports %>%
  semi_join(flights, c("faa" = "dest")) %>%
  ggplot(aes(lon, lat)) +
  borders("state") +
  geom_point() +
  coord_quickmap()

# >> solution
avg_delay_in_dest <- flights %>% 
  group_by(dest) %>%
  summarise(avg_arr_delay = mean(arr_delay, na.rm = TRUE)) %>%
  left_join(airports, by = c('dest' = 'faa')) 

avg_delay_in_dest %>%
  ggplot(aes(x = lon, y = lat,color = avg_arr_delay)) +
  borders('state') +
  geom_point() +
  coord_quickmap()

################### Exercise 13.4.2 ###################
#Add the location of the origin and destination (i.e. the lat and lon) to flights

flights %>%
  left_join(select(airports, faa, lat, lon), by = c("origin" = "faa")) %>%
  rename(lat_origin = lat,
         lon_origin = lon) %>%
  left_join(select(airports, faa, lat, lon), by = c("dest" = "faa")) %>%
  rename(lat_dest = lat,
         lon_dest = lon) %>%
  select(origin, dest, matches("lat|lon"))

################### Exercise 13.4.3 ###################
#Is there a relationship between the age of a plane and its delays?

flights %>%
  mutate(total_delay = arr_delay + dep_delay) %>%
  group_by(tailnum) %>%
  summarise(avg_delay = mean(total_delay, na.rm = TRUE)) %>%
  left_join(planes, by = 'tailnum') %>%
  ggplot(aes(avg_delay, year)) +
  geom_point() +
  geom_smooth()

################### Exercise 13.4.4 ###################
#What weather conditions make it more likely to see a delay?



#################### Exercise 13.4.5 ###################
#What happened on June 13 2013? Display the spatial pattern of delays, 
#and then use Google to cross-reference with the weather


flights %>% 
  filter(year == 2013, month == 6, day == 13) %>%
  group_by(dest) %>%
  summarise(avg_arr_delay = mean(arr_delay, na.rm = TRUE)) %>%
  left_join(airports, by = c('dest' = 'faa')) %>%
  ggplot(aes(x = lon, y = lat, color = avg_arr_delay)) +
  borders('state') +
  geom_point()+
  coord_quickmap()


#################### Exercise 13.5.1 ###################
#What does it mean for a flight to have a missing tailnum? What do the tail 
#numbers that don’t have a matching record in planes have in common? 
#(Hint: one variable explains ~90% of the problems.)

# >> Flights have a missing tailnum are those that were cancellled, or  
# >> have missing dep_time , arr_time

flights %>%
  filter(is.na(tailnum), !is.na(arr_time), !is.na(dep_time)) %>%
  nrow()

#################### Exercise 13.5.2 ###################
#Filter flights to only show flights with planes that have flown at least 100 flights

planes_flown_100 <- flights %>%
  filter(!is.na(tailnum)) %>%
  group_by(tailnum) %>%
  count() %>%
  filter(n >= 100)

flights %>%
  semi_join(planes_flown_100, by = "tailnum")

#################### Exercise 13.5.3 ###################
#Combine fueleconomy::vehicles and fueleconomy::common to find only the 
#records for the most common models.

View(vehicles)
View(common)
 
fueleconomy::vehicles %>%
  semi_join(fueleconomy::common, by = c('make', 'model'))

#################### Exercise 13.5.4 ###################
#Find the 48 hours (over the course of the whole year) that have the worst delays. 
#Cross-reference it with the weather data. Can you see any patterns?

worst_hours <- flights %>%
  mutate(hour = sched_dep_time %/% 100) %>%
  group_by(origin, year, month, day, hour) %>%
  summarise(dep_delay = mean(dep_delay, na.rm = TRUE)) %>%
  ungroup() %>%
  arrange(desc(dep_delay)) %>%
  slice(1:48)

weather_most_delayed <- left_join(weather, worst_hours, 
                                  by = c("origin", "year",
                                         "month", "day", "hour"))

ggplot(weather_most_delayed, aes(x = precip, y = wind_speed, color = temp)) +
  geom_point()

# >> I do'nt know

#################### Exercise 13.5.5 ###################
#What does anti_join(flights, airports, by = c("dest" = "faa")) tell you? 
#What does anti_join(airports, flights, by = c("faa" = "dest")) tell you?

anti_join(flights, airports, by = c("dest" = "faa")) # >> Gives the flights 
# >> from the destionations that are not present in the `airports` dataset.

anti_join(airports, flights, by = c("faa" = "dest")) # >> Gives the airports 
# >> that are not present as destinations in the `flights` dataset.

#################### Exercise 13.5.6 ###################
#You might expect that there’s an implicit relationship between plane and airline, 
#because each plane is flown by a single airline. Confirm or reject this hypothesis 
#using the tools you’ve learned above

#find all distinct airline, plane combinations,number of planes that have flown for more than one
flights %>%
  filter(!is.na(tailnum)) %>%
  distinct(tailnum, carrier)%>%
  count(tailnum) %>%
  filter(n > 1) %>%
  nrow()

#join with airlines to get airline names
planes_carriers <- flights %>%
  group_by(tailnum) %>%
  filter(n() > 1) %>%
  left_join(airlines, by = "carrier") %>%
  arrange(tailnum, carrier)



