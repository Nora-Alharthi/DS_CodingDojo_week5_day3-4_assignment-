library(ggplot2)
library(tidyverse)


################### Exercise 12.2.1 ###################
#Using prose, describe how the variables and observations are organized in each of the sample tables.

# >> In table table1, each row represents the country, year, and values of cases and population 
# >> In table2, each row represents the country, year, the column count contains the values of cases and 
# >> population but in separate rows,the cases and population columns from previous table were separated in 2 rows
# >> In table3, each row represents the country, year, the column rate provides the values of cases divided by 
# >> population in a string formatted like "cases / population"
# >> In table table4a each row represents a country,the value of the cases  in year
# >> In table4b each row represents a country,the value of the population  in year


################### Exercise 12.2.2 ###################
#Compute the rate for table2, and table4a + table4b. You will need to perform four operations:
#Extract the number of TB cases per country per year.
#Extract the matching population per country per year.
#Divide cases by population, and multiply by 10000.
#Store back in the appropriate place.
#Which representation is easiest to work with? Which is hardest? Why?

# >> For table2:

#create separate tables for cases
table2_cases <- filter(table2, type == "cases") %>%
  rename(cases = count) %>%
  arrange(country, year)
#create separate tables for population
table2_population <- filter(table2, type == "population") %>%
  rename(population = count) %>%
  arrange(country, year)
#create a new data frame with the population and cases columns, 
#and calculate the cases per population in a new column
table2_cases_per_pop <- tibble(
  year = table2_cases$year,
  country = table2_cases$country,
  cases = table2_cases$cases,
  population = table2_population$population
) %>%
  mutate(cases_per_pop = (cases / population) * 10000) %>%
  select(country, year, cases_per_pop)
#creates the new variable with its associated numbers within each row
table2_cases_per_pop <- table2_cases_per_pop %>%
  mutate(type = "cases_per_pop") %>%
  rename(count = cases_per_pop)
#combines table2 and t2_cases_per_pop
bind_rows(table2, table2_cases_per_pop) %>%
  arrange(country, year, type, count)

# >> For table4a & table4b
#create a new table for cases per population
table4c <-
  tibble(
    country = table4a$country,
    `1999` = table4a[["1999"]] / table4b[["1999"]] * 10000,
    `2000` = table4a[["2000"]] / table4b[["2000"]] * 10000
  )
table4c

# >> Since table2 has separate rows for cases and population we needed to 
# >> generate a table with columns for cases and population where we could 
# >> calculate cases per population,this is hardest to work with 
# >> table4a and table4b split the cases and population variables into different 
# >> tables which made it easy to divide cases by population,this is easiest 
# >> This was the first time I had to manipulate data like this in R


################### Exercise 12.2.3 ###################
#Recreate the plot showing change in cases over time using table2 instead of table1. 
#What do you need to do first?

# >> we need to filter table to only include rows representing cases of TB
table2 %>%
  filter(type == "cases") %>%
  ggplot(aes(year, count)) + 
  geom_line(aes(group = country), colour = "grey50") + 
  geom_point(aes(colour = country)) + 
  scale_x_continuous(breaks = unique(table2$year)) + 
  ylab("cases")

################### Exercise 12.3.1 ###################
#Why are pivot_longer() and pivot_wider() not perfectly symmetrical? 
#Carefully consider the following example:

stocks <- tibble(
  year   = c(2015, 2015, 2016, 2016),
  half  = c(   1,    2,     1,    2),
  return = c(1.88, 0.59, 0.92, 0.17)
)
#pivot_wider()
stocks %>%
  pivot_wider(names_from = year, values_from = return)

stocks %>% 
  pivot_wider(names_from = year, values_from = return) %>% 
  pivot_longer(`2015`:`2016`, names_to = "year", values_to = "return")


# >> The pivot_wider() expression pivots the table to create a data frame with 
# >> years as column names, and the values in return as the column values
# >> The pivot_longer() expression unpivots the table, returning it to a tidy 
# >> data frame with columns for half, year, and return


################### Exercise 12.3.2 ###################
#Why does this code fail?

table4a %>% 
  pivot_longer(c(1999, 2000), names_to = "year", values_to = "cases")

# >> The reason why the code above fails is because that 1999 and 2000 are 
# >> characters in the table and not integers 
# >> we want to refer to columns within a table we need to be careful whether 
# >> the columns we wish to represent are integers or characters.

#To make it work, I add ' to both sides of 1999 and 2000
table4a %>% 
  pivot_longer(c('1999', '2000'), names_to = "year", values_to = "cases")


################### Exercise 12.3.3 ###################
#What would happen if you widen this table? Why? 
#How could you add a new column to uniquely identify each value?

people <- tribble(
  ~name,             ~names,  ~values,
  #-----------------|--------|------
  "Phillip Woods",   "age",       45,
  "Phillip Woods",   "height",   186,
  "Phillip Woods",   "age",       50,
  "Jessica Cordero", "age",       37,
  "Jessica Cordero", "height",   156
)

people %>%
  pivot_wider(names_from = names, values_from = values)

# >> This warning is important as it gives us the opportunity to see how to work
# >> with duplicated data


################### Exercise 12.3.4 ###################
#Tidy the simple tibble below. Do you need to make it wider or longer? 
#What are the variables?

preg <- tribble(
  ~pregnant, ~male, ~female,
  "yes",     NA,    10,
  "no",      20,    12
)

preg %>%
  pivot_longer(c(male, female), names_to = "sex", values_to = "count")

################### Exercise 12.4.1 ###################
#What do the extra and fill arguments do in separate()? Experiment with the 
#various options for the following two toy datasets.

tibble(x = c("a,b,c", "d,e,f,g", "h,i,j")) %>% 
  separate(x, c("one", "two", "three"))

tibble(x = c("a,b,c", "d,e", "f,g,i")) %>% 
  separate(x, c("one", "two", "three"))

# >> The extra argument tells separate() what to do if there are too many pieces,
# >> and the fill argument tells it what to do if there aren’t enough 
# >> By default, separate() drops extra values with a warning.
# >> 

#Add the argument, extra = "drop", to provide the same result as above but 
#without the error or warning
tibble(x = c("a,b,c", "d,e,f,g", "h,i,j")) %>%
  separate(x, c("one", "two", "three"), extra = "drop")

#Setting extra = "merge", then the extra values are not split, so "f,g" and "j,k"
#appears in column three
tibble(x = c("a,b,c", "d,e,f,g", "h,i,j,k")) %>%
  separate(x, c("one", "two", "three"), extra = "merge")

#"a,b" has too few elements. The default for fill is similar to those in separate()
#it fills columns with missing values but emits a warning
tibble(x = c("a,b", "c,d,e,f", "g,h,i,")) %>%
  separate(x, c("one", "two", "three"))

#To fill with missing values from the right, but without a warning
tibble(x = c("a,b,c", "d,e", "f,g,i")) %>%
  separate(x, c("one", "two", "three"), fill = "right")

#To fill with missing values from the left, but without a warning
tibble(x = c("a,b,c", "d,e", "f,g,i")) %>%
  separate(x, c("one", "two", "three"), fill = "left")

################### Exercise 12.4.2 ###################
#Both unite() and separate() have a remove argument. 
#What does it do? Why would you set it to FALSE?


# >> The remove argument does away with the imputed columns in the result data 
# >> frame, and the FALSE means that you want to create a new variable but keep 
#>> the old one


################### Exercise 12.4.3 ###################
#Compare and contrast separate() and extract(), Why are there three variations 
#of separation (by position, by separator, and with groups), but only one unite?

# >> The function separate(), splits a column into multiple columns by separator

#separate
tibble(x = c("John_25", "Mark_28", "Sam_26")) %>%
  separate(x, c("name", "age"), sep = "_")

tibble(x = c("John25", "Mark28", "Sam26")) %>%
  separate(x, c("name", "age"), sep = c(4))

tibble(x = c("Jonh25", "Mark28", "Sami26")) %>%
  separate(x, c("name", "age"), sep = c(4))

#extract
tibble(x = c("N_5", "M_8", "N_6", "M_4")) %>%
  extract(x, c("name", "id"), regex = "([A-Z])_([0-9])")

tibble(x = c("N1", "N2", "M1", "M2")) %>%
  extract(x, c("variable", "id"), regex = "([A-Z])([0-9])")

tibble(x = c("NN1", "N20", "MM11", "MM2")) %>%
  extract(x, c("variable", "id"), regex = "([A-Z]+)([0-9]+)")

# >> Both separate() and extract() convert a single column to many columns. 
# >> However, unite() converts many columns to one, with a choice of a separator 
# >> to include between column values

tibble(variable = c("N", "N", "M", "M"), id = c(2, 5, 2, 5)) %>%
  unite(x, variable, id, sep = "_")

################### Exercise 12.5.1 ###################
#Compare and contrast the fill arguments to pivot_wider() and complete(). 

# >> Both spread() and complete() replace implicit and explicit missing values. 
# >> In spread(), the fill argument *explicitly* sets the value to replace NAs. 
# >> The fill argument in complete() allows for different values of different variables.

#this will fill in the missing values of the long data frame with 0 complete():
stocks <- tibble(
  year   = c(2015, 2015, 2015, 2015, 2016, 2016, 2016),
  qtr    = c(   1,    2,    3,    4,    2,    3,    4),
  return = c(1.88, 0.59, 0.35,   NA, 0.92, 0.17, 2.66)
)

stocks %>% 
  pivot_wider(names_from = year, values_from = return,
              values_fill = 0)

stocks %>% 
  complete(year, qtr, fill=list(return=0))


################### Exercise 12.5.2 ###################
#What does the direction argument to fill() do?

# >> The direction determines whether the missing values should be replaced by 
# >> values from above or below or "up" and "down"

################### Exercise 12.6.1 ###################

#>>> code from the chapter
who1 <- who %>% 
  pivot_longer(
    cols = new_sp_m014:newrel_f65, 
    names_to = "key", 
    values_to = "cases", 
    values_drop_na = TRUE
  )
who1

who2 <- who1 %>% 
  mutate(names_from = stringr::str_replace(key, "newrel", "new_rel"))
who2

who3 <- who2 %>% 
  separate(key, c("new", "type", "sexage"), sep = "_")

who3 %>%
  count(new)

who4 <- who3 %>%
  select(-new, -iso2, -iso3)
who4

who5 <- who4 %>%
  separate(sexage, c("sex", "age"), sep = 1)
who5

#In this case study I set values_drop_na = TRUE just to make it easier to check 
#that we had the correct values. Is this reasonable? Think about how missing 
#values are represented in this dataset. Are there implicit missing values? 
#What’s the difference between an NA and zero?

# >> If there are no 0 values, then that means there is no data or no cases in 
# >> the who database. If there are explicit or implicit missing values, then it
# >> mean that missing values are being used in different ways
# >> NA would mean no cases and implicit would mean no data on the number of cases

who1 <- who %>% 
  pivot_longer(
    cols = new_sp_m014:newrel_f65, 
    names_to = "key", 
    values_to = "cases", 
    values_drop_na = TRUE
  )

#To check for the presence of zeros in the data
who1 %>%
  filter(cases == 0) %>%
  nrow()

# >> There are zeros in the data, so it appears that cases of zero TB are 
# >> explicitly indicated, and the value of NA is used to indicate missing data


################### Exercise 12.6.2 ###################
#What happens if you neglect the mutate() step? 
#(mutate(names_from = stringr::str_replace(key, “newrel”, “new_rel”)))

# >> If I neglect this then the separate() function emits the warning 
# >> "Expected 3 pieces. Missing pieces filled with `NA`"

who6 <- who1 %>%
  separate(key, c("new", "type", "sexage"), sep = "_")


################### Exercise 12.6.3 ###################
#I claimed that iso2 and iso3 were redundant with country. Confirm this claim.

select(who3, country, iso2, iso3) %>%
  distinct() %>%
  group_by(country) %>%
  filter(n() > 1)

# >> iso2 and iso3 are redundant and should be one combination of the two values
# >> both iso2 and iso3 contain the 2 and 3 letter abbreviations for the country


################### Exercise 12.6.4 ###################
# For each country, year, and sex compute the total number of cases of TB. 
#Make an informative visualization of the data.


who5 %>%
  group_by(country, year, sex) %>%
  filter(year > 2000) %>%
  summarise(cases = sum(cases)) %>%
  unite(country_sex, country, sex, remove = FALSE) %>%
  ggplot(aes(x = year, y = cases, group = country_sex, colour = sex)) +
  geom_line()

